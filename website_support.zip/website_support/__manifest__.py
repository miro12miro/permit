{
    'name': "Permit/Concession",
    'version': "1.0.11",
    'author': "Marwan benmohamed",
    'category': "Tools",
    'summary': "Permit/Concession",
    'description': "Permit/Concession",
    'license':'LGPL-3',
    'data': [
        'views/website_support_ticket_views.xml',
        'views/menus.xml',
    ],
    'demo': [],
    'depends': ['mail','web', 'resource'],
    'images':[
        'static/description/3.jpg',
        'static/description/1.jpg',
        'static/description/2.jpg',
        'static/description/4.jpg',
        'static/description/5.jpg',
        'static/description/6.jpg',
    ],
    'installable': True,
}