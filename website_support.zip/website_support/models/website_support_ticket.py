# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools
from random import randint
import datetime
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from odoo import SUPERUSER_ID
from dateutil import tz
from odoo.http import request

import logging
_logger = logging.getLogger(__name__)

class WebsiteSupportTicket(models.Model):

    _name = "website.support.ticket"
    _description = "Website Support Ticket"
    _order = "create_date desc"
    _rec_name = "channel"
    _inherit = ['mail.thread']
    _translate = True

    channel = fields.Char(string="Name")
